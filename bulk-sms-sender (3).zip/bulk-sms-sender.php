<?php
/**
 * Plugin Name: Bulk SMS and Email Sender
 * Description: Allows admin to send bulk SMS and emails to users, and shows notifications for each successful send.
 * Version: 1.2
 * Author: Your Name
 */

// Security check to prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

const API_TOKEN = "0ibjjz2c-zh3fxaqv-rzbphkyl-u9lhsfpo-t1xwm8ct"; //put SSL provided api_token here
const SID = "MEXEMYMASK"; // put SSL provided SID here
const DOMAIN = "https://smsplus.sslwireless.com/"; // API domain

/**
 * Create Admin Menu Page
 */
function bulk_sms_email_sender_menu() {
    add_menu_page(
        'Bulk SMS & Email Sender',  // Page title
        'Bulk SMS & Email Sender',  // Menu title
        'manage_options',           // Capability
        'bulk-sms-email-sender',    // Menu slug
        'bulk_sms_sender_page',     // Callback function
        'dashicons-email-alt',      // Icon
        90                          // Position
    );

    // Add submenu for Bulk Email Sender
    add_submenu_page(
        'bulk-sms-email-sender',    // Parent slug
        'Bulk Email Sender',        // Page title
        'Bulk Email Sender',        // Menu title
        'manage_options',           // Capability
        'bulk-email-sender',        // Menu slug
        'bulk_email_sender_page'    // Callback function
    );
    
    
    
    // Add submenu for OTP Sender
    add_submenu_page(
        'bulk-sms-email-sender',     // Parent slug
        'OTP Sender',                // Page title
        'OTP Sender',                // Menu title
        'manage_options',            // Capability
        'otp-sender',                // Menu slug
        'otp_sender_page'            // Callback function
    );
    
}
add_action('admin_menu', 'bulk_sms_email_sender_menu');

/**
 * Admin Page for Bulk SMS
 */
function bulk_sms_sender_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Handle form submission for SMS
    if (isset($_POST['send_sms'])) {
        $phone_numbers = sanitize_text_field($_POST['phone_numbers']);
        $message_body = sanitize_textarea_field($_POST['message_body']);
        $csms_id = uniqid(); // Unique CSMS ID

        // Convert phone numbers to an array
        $phone_numbers_array = explode(",", $phone_numbers);

        echo '<div class="notice notice-info is-dismissible">';
        
        // Send SMS to each number
        foreach ($phone_numbers_array as $msisdn) {
            $msisdn = trim($msisdn);
            $response = singleSms($msisdn, $message_body, $csms_id);

            $response_data = json_decode($response, true);

            if (isset($response_data['status']) && $response_data['status'] === 'SUCCESS') {
                echo '<p>SMS sent successfully to ' . esc_html($msisdn) . '</p>';
            } else {
                echo '<p>Failed to send SMS to ' . esc_html($msisdn) . '</p>';
            }
        }

        echo '</div>';
    }

    // Form for sending SMS
    echo '<div class="wrap">
        <h1>Bulk SMS Sender</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Phone Numbers (comma separated)</th>
                    <td><textarea name="phone_numbers" rows="5" cols="50" required></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Message</th>
                    <td><textarea name="message_body" rows="5" cols="50" required></textarea></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="send_sms" class="button-primary" value="Send SMS">
            </p>
        </form>
    </div>';
}

/**
 * Admin Page for Bulk Email
 */
function bulk_email_sender_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Handle form submission for email
    if (isset($_POST['send_email'])) {
        $emails = sanitize_text_field($_POST['email_addresses']);
        $email_subject = sanitize_text_field($_POST['email_subject']);
        $email_body = wp_kses_post($_POST['email_body']);

        // Convert emails into an array
        $email_array = explode(",", $emails);

        echo '<div class="notice notice-info is-dismissible">';
        
        // Send email to each address
        foreach ($email_array as $email) {
            $email = trim($email);
            $headers = ['Content-Type: text/html; charset=UTF-8'];

            // Send email
            if (wp_mail($email, $email_subject, $email_body, $headers)) {
                echo '<p>Email sent successfully to ' . esc_html($email) . '</p>';
            } else {
                echo '<p>Failed to send email to ' . esc_html($email) . '</p>';
            }
        }

        echo '</div>';
    }

    // Form for sending bulk emails
    echo '<div class="wrap">
        <h1>Bulk Email Sender</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Email Addresses (comma separated)</th>
                    <td><textarea name="email_addresses" rows="5" cols="50" required></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Subject</th>
                    <td><input type="text" name="email_subject" value="" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Message</th>
                    <td><textarea name="email_body" rows="10" cols="50" required></textarea></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="send_email" class="button-primary" value="Send Email">
            </p>
        </form>
    </div>';
}

/**
 * Function to send SMS using SSL API
 */
function singleSms($msisdn, $messageBody, $csmsId) {
    $params = [
        "api_token" => API_TOKEN,
        "sid" => SID,
        "msisdn" => $msisdn,
        "sms" => $messageBody,
        "csms_id" => $csmsId
    ];
    $url = trim(DOMAIN, '/')."/api/v3/send-sms";
    $params = json_encode($params);

    $response = callApi($url, $params);
    return $response;
}

/**
 * Function to call the API using cURL
 */
function callApi($url, $params) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: ' . strlen($params),
        'accept:application/json'
    ));

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}


/**
 * Admin Page for OTP Sender
 */
function otp_sender_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Handle form submission for sending OTP
    if (isset($_POST['send_otp'])) {
        $phone_number = sanitize_text_field($_POST['phone_number']);
        $otp = rand(100000, 999999); // Generate a 6-digit OTP
        $message_body = "Your OTP is: " . $otp;
        $csms_id = uniqid(); // Unique CSMS ID

        // Send the OTP via SMS
        $response = singleSms($phone_number, $message_body, $csms_id);
        $response_data = json_decode($response, true);

        if (isset($response_data['status']) && $response_data['status'] === 'SUCCESS') {
            echo '<div class="notice notice-info is-dismissible">';
            echo '<p>OTP sent successfully to ' . esc_html($phone_number) . '</p>';
            echo '</div>';

            // Store the OTP in a transient (temporary storage) for 10 minutes
            set_transient('user_otp_' . $phone_number, $otp, 10 * MINUTE_IN_SECONDS);
        } else {
            echo '<div class="notice notice-error is-dismissible">';
            echo '<p>Failed to send OTP to ' . esc_html($phone_number) . '</p>';
            echo '</div>';
        }
    }

    // Handle form submission for verifying OTP
    if (isset($_POST['verify_otp'])) {
        $phone_number = sanitize_text_field($_POST['phone_number']);
        $entered_otp = sanitize_text_field($_POST['otp']);

        // Retrieve the OTP from the transient
        $stored_otp = get_transient('user_otp_' . $phone_number);

        if ($stored_otp && $entered_otp == $stored_otp) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>OTP verified successfully for ' . esc_html($phone_number) . '</p>';
            echo '</div>';

            // Delete the OTP after verification
            delete_transient('user_otp_' . $phone_number);
        } else {
            echo '<div class="notice notice-error is-dismissible">';
            echo '<p>Invalid OTP for ' . esc_html($phone_number) . '</p>';
            echo '</div>';
        }
    }

    // Form for sending OTP
    echo '<div class="wrap">
        <h1>Send OTP</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Phone Number</th>
                    <td><input type="text" name="phone_number" required></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="send_otp" class="button-primary" value="Send OTP">
            </p>
        </form>
    </div>';

    // Form for verifying OTP
    echo '<div class="wrap">
        <h1>Verify OTP</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Phone Number</th>
                    <td><input type="text" name="phone_number" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row">OTP</th>
                    <td><input type="text" name="otp" required></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="verify_otp" class="button-primary" value="Verify OTP">
            </p>
        </form>
    </div>';
}





